import pandas as pd

df = pd.read_excel("data.xlsx", sheet_name='data', usecols=['corr_net_gdp_pcap','corr_mob_gdp_pcap'])
data = pd.DataFrame(columns=['corr_net_gdp_pcap','corr_mob_gdp_pcap'])

data.loc['count'] = df.count()
data.loc['mean'] = df.mean()
data.loc['std'] = df.std()
data.loc['var'] = df.var()
data.loc['median'] = df.median()
data.loc['min'] = df.min()
data.loc['max'] = df.max()

print('\n')
print(data)
print('\n')