import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

df = pd.read_excel("data.xlsx", sheet_name='data')

df_fig = sns.boxplot(data=df)
plt.savefig('fig_box')
plt.close()