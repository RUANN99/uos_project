import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

df = pd.read_excel("data.xlsx", sheet_name='data')

df_fig = sns.pairplot(df)
plt.savefig('fig')
plt.close()