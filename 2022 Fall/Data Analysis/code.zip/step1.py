import pandas as pd
from pandas import ExcelWriter
import seaborn as sns
import matplotlib.pyplot as plt

#엑셀파일 읽고 비어있는 데이터 있으면 해당 나라를 파일에 제거하기
df_net = pd.read_excel("net_user_per.xlsx", sheet_name='Data2')
df_net = df_net.dropna()
df_net.to_excel("net_data.xlsx", sheet_name='data')

df_gdp_pcap = pd.read_excel("gdp_pcap.xlsx", sheet_name='Data2')
df_gdp_pcap = df_gdp_pcap.dropna()

df_mob = pd.read_excel("mobile.xlsx", sheet_name='Data')
df_mob = df_mob.dropna()

#나라 리스트 만들기
df = pd.read_excel("net_data.xlsx", sheet_name='data', usecols=[1,2])
df = pd.concat([df, pd.DataFrame(columns=['corr_net_gdp_pcap','corr_mob_gdp_pcap'])], sort=False)

#나라별 인터넷 보급률 및 gdp의 상관관계 구하기
w = ExcelWriter('grp.xlsx')
for c_code in df['Country Code']:

    #해당나라 자료 추출
    n_data = df_net.loc[df_net['Country Code'] == c_code]
    gpcap_data = df_gdp_pcap.loc[df_gdp_pcap['Country Code'] == c_code]
    mob_data = df_mob.loc[df_mob['Country Code'] == c_code]

    #상관계수 계산
    corr1 = n_data.corrwith(other=gpcap_data, method='pearson', axis=1).values
    corr2 = mob_data.corrwith(other=gpcap_data, method='pearson', axis=1).values

    #자료 통합
    grp = pd.concat([n_data, mob_data])
    grp = pd.concat([grp, gpcap_data])
    
    #상관계수 계산 결과 저장
    idx = df.index[df['Country Code'] == c_code]
    df.loc[idx, 'corr_net_gdp_pcap'] = corr1
    df.loc[idx, 'corr_mob_gdp_pcap'] = corr2

    #각 나라 별로 자료 생성
    grp.to_excel(w, sheet_name=c_code, index=False)

w.save()

#출력
df.to_excel('data.xlsx', sheet_name='data', index=False)



