import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

df = pd.read_excel("data.xlsx", sheet_name='data')

df_fig = sns.violinplot(data=df)
plt.savefig('fig_violin')
plt.close()